# TomaShops™ Video 1st Marketplace

A modern, video-first marketplace platform built with Next.js 14, Prisma, and TypeScript.

## Features

- Video-first product listings
- User authentication (buyers and sellers)
- Admin dashboard
- In-app messaging
- Stripe integration for payments
- Local transaction support
- Search functionality
- Wishlist
- Shopping cart
- Maps integration
- Google AdSense integration

## Tech Stack

- Next.js 14 (App Router)
- TypeScript
- Prisma (PostgreSQL)
- TailwindCSS
- NextAuth.js
- Stripe
- Mux (Video hosting)
- UploadThing (File uploads)
- Google Maps API

## Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up environment variables:
   ```bash
   cp .env.example .env
   ```
4. Initialize the database:
   ```bash
   npx prisma db push
   ```
5. Run the development server:
   ```bash
   npm run dev
   ```

## Environment Variables

Create a `.env` file with the following variables:

```env
DATABASE_URL="postgresql://..."
NEXTAUTH_SECRET="your-secret"
STRIPE_SECRET_KEY="..."
STRIPE_WEBHOOK_SECRET="..."
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="..."
UPLOADTHING_SECRET="..."
UPLOADTHING_APP_ID="..."
MUX_TOKEN_ID="..."
MUX_TOKEN_SECRET="..."
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY="..."
```

## License

All rights reserved. This project is proprietary software. 