"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select } from "@/components/ui/select"
import { useUploadThing } from "@/lib/uploadthing"
import { useSession } from "next-auth/react"
import { Icons } from "@/components/icons"

const formSchema = z.object({
  title: z.string().min(3).max(100),
  description: z.string().min(10).max(1000),
  price: z.number().min(0),
  condition: z.enum(["NEW", "LIKE_NEW", "GOOD", "FAIR", "POOR"]),
  location: z.string().min(3),
  categoryId: z.string(),
  images: z.array(z.string()).min(1),
  videoUrl: z.string().optional(),
})

export default function CreateListingPage() {
  const router = useRouter()
  const { data: session } = useSession()
  const [isLoading, setIsLoading] = React.useState(false)
  const [categories, setCategories] = React.useState([])

  const { startUpload } = useUploadThing("imageUploader")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      price: 0,
      condition: "NEW",
      location: "",
      categoryId: "",
      images: [],
      videoUrl: "",
    },
  })

  React.useEffect(() => {
    const fetchCategories = async () => {
      const response = await fetch("/api/categories")
      const data = await response.json()
      setCategories(data)
    }
    fetchCategories()
  }, [])

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      setIsLoading(true)

      const response = await fetch("/api/listings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      })

      if (response.ok) {
        router.push("/listings")
      }
    } catch (error) {
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  if (!session) {
    return (
      <div className="container flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Please sign in to create a listing</h1>
          <Button
            className="mt-4"
            onClick={() => router.push("/auth/signin")}
          >
            Sign In
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container max-w-2xl py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Create a New Listing</h1>
        <p className="text-muted-foreground">
          Fill out the form below to create your listing
        </p>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="space-y-4">
          <Input
            {...form.register("title")}
            placeholder="Title"
            disabled={isLoading}
          />
          <Textarea
            {...form.register("description")}
            placeholder="Description"
            disabled={isLoading}
          />
          <Input
            {...form.register("price", { valueAsNumber: true })}
            type="number"
            placeholder="Price"
            disabled={isLoading}
          />
          <Select
            {...form.register("condition")}
            disabled={isLoading}
          >
            <option value="NEW">New</option>
            <option value="LIKE_NEW">Like New</option>
            <option value="GOOD">Good</option>
            <option value="FAIR">Fair</option>
            <option value="POOR">Poor</option>
          </Select>
          <Input
            {...form.register("location")}
            placeholder="Location"
            disabled={isLoading}
          />
          <Select
            {...form.register("categoryId")}
            disabled={isLoading}
          >
            {categories.map((category: any) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </Select>
          <div className="space-y-2">
            <label className="block text-sm font-medium">Images</label>
            <Input
              type="file"
              accept="image/*"
              multiple
              onChange={async (e) => {
                const files = Array.from(e.target.files || [])
                const uploadedImages = await startUpload(files)
                if (uploadedImages) {
                  const urls = uploadedImages.map((image) => image.url)
                  form.setValue("images", urls)
                }
              }}
              disabled={isLoading}
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium">Video</label>
            <Input
              type="file"
              accept="video/*"
              onChange={async (e) => {
                const file = e.target.files?.[0]
                if (file) {
                  // Handle video upload
                }
              }}
              disabled={isLoading}
            />
          </div>
        </div>
        <Button type="submit" disabled={isLoading}>
          {isLoading && (
            <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
          )}
          Create Listing
        </Button>
      </form>
    </div>
  )
} 