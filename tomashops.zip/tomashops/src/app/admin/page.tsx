"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Icons } from "@/components/icons"

export default function AdminDashboard() {
  const router = useRouter()
  const { data: session } = useSession()
  const [isLoading, setIsLoading] = React.useState(false)
  const [categories, setCategories] = React.useState([])
  const [users, setUsers] = React.useState([])
  const [listings, setListings] = React.useState([])

  React.useEffect(() => {
    if (!session?.user || session.user.role !== "ADMIN") {
      router.push("/")
    }
  }, [session, router])

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)
        const [categoriesRes, usersRes, listingsRes] = await Promise.all([
          fetch("/api/categories"),
          fetch("/api/users"),
          fetch("/api/listings"),
        ])
        const [categoriesData, usersData, listingsData] = await Promise.all([
          categoriesRes.json(),
          usersRes.json(),
          listingsRes.json(),
        ])
        setCategories(categoriesData)
        setUsers(usersData)
        setListings(listingsData)
      } catch (error) {
        console.error(error)
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [])

  if (!session?.user || session.user.role !== "ADMIN") {
    return null
  }

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">
          Manage your marketplace settings and content
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Active Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {listings.filter((l: any) => l.status === "ACTIVE").length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{categories.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="categories" className="mt-8">
        <TabsList>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="listings">Listings</TabsTrigger>
        </TabsList>
        <TabsContent value="categories" className="space-y-4">
          <div className="flex justify-between">
            <h2 className="text-xl font-semibold">Manage Categories</h2>
            <Button onClick={() => router.push("/admin/categories/new")}>
              Add Category
            </Button>
          </div>
          <div className="divide-y rounded-md border">
            {categories.map((category: any) => (
              <div
                key={category.id}
                className="flex items-center justify-between p-4"
              >
                <div>
                  <h3 className="font-medium">{category.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {category.description}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => router.push(`/admin/categories/${category.id}`)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={async () => {
                      if (
                        window.confirm(
                          "Are you sure you want to delete this category?"
                        )
                      ) {
                        await fetch(`/api/categories?id=${category.id}`, {
                          method: "DELETE",
                        })
                        setCategories(
                          categories.filter((c: any) => c.id !== category.id)
                        )
                      }
                    }}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="users" className="space-y-4">
          <div className="flex justify-between">
            <h2 className="text-xl font-semibold">Manage Users</h2>
            <Input
              placeholder="Search users..."
              className="max-w-xs"
              onChange={(e) => {
                // Implement user search
              }}
            />
          </div>
          <div className="divide-y rounded-md border">
            {users.map((user: any) => (
              <div
                key={user.id}
                className="flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-4">
                  {user.image && (
                    <img
                      src={user.image}
                      alt={user.name}
                      className="h-10 w-10 rounded-full"
                    />
                  )}
                  <div>
                    <h3 className="font-medium">{user.name}</h3>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={async () => {
                    if (
                      window.confirm(
                        "Are you sure you want to delete this user?"
                      )
                    ) {
                      await fetch(`/api/users?id=${user.id}`, {
                        method: "DELETE",
                      })
                      setUsers(users.filter((u: any) => u.id !== user.id))
                    }
                  }}
                >
                  Delete
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="listings" className="space-y-4">
          <div className="flex justify-between">
            <h2 className="text-xl font-semibold">Manage Listings</h2>
            <Input
              placeholder="Search listings..."
              className="max-w-xs"
              onChange={(e) => {
                // Implement listing search
              }}
            />
          </div>
          <div className="divide-y rounded-md border">
            {listings.map((listing: any) => (
              <div
                key={listing.id}
                className="flex items-center justify-between p-4"
              >
                <div>
                  <h3 className="font-medium">{listing.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {listing.user.name} • {listing.status}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => router.push(`/listings/${listing.id}`)}
                  >
                    View
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={async () => {
                      if (
                        window.confirm(
                          "Are you sure you want to delete this listing?"
                        )
                      ) {
                        await fetch(`/api/listings?id=${listing.id}`, {
                          method: "DELETE",
                        })
                        setListings(
                          listings.filter((l: any) => l.id !== listing.id)
                        )
                      }
                    }}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
} 