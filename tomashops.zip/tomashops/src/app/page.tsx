import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CategoryCard } from "@/components/category-card"
import { ListingCard } from "@/components/listing-card"
import { getFeaturedListings } from "@/lib/listings"
import { getCategories } from "@/lib/categories"

export default async function HomePage() {
  const featuredListings = await getFeaturedListings()
  const categories = await getCategories()

  return (
    <div className="flex flex-col gap-8 py-8">
      {/* Hero Section */}
      <section className="container flex flex-col items-center gap-4 text-center">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
          Welcome to TomaShops™
        </h1>
        <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
          The Video-First Marketplace. Buy and sell with confidence using our innovative video listings platform.
        </p>
        <div className="flex gap-4">
          <Button asChild size="lg">
            <Link href="/browse">Start Shopping</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/sell">Start Selling</Link>
          </Button>
        </div>
      </section>

      {/* Categories Section */}
      <section className="container space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Categories</h2>
          <Button asChild variant="ghost">
            <Link href="/categories">View All</Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </section>

      {/* Featured Listings Section */}
      <section className="container space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight">Featured Listings</h2>
          <Button asChild variant="ghost">
            <Link href="/browse">View All</Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {featuredListings.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      </section>

      {/* Trust Section */}
      <section className="container">
        <div className="rounded-lg bg-muted p-8">
          <div className="grid gap-8 md:grid-cols-3">
            <div className="text-center">
              <h3 className="text-lg font-semibold">Secure Payments</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Protected by Stripe with buyer and seller protection
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-lg font-semibold">Video First</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                See items in action before you buy
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-lg font-semibold">Local or Shipped</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Choose between local pickup or nationwide shipping
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
} 