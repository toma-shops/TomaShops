"use client"

import * as React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"

const items = [
  {
    title: "Browse",
    href: "/browse",
  },
  {
    title: "Categories",
    href: "/categories",
  },
  {
    title: "Sell",
    href: "/sell",
  },
  {
    title: "Local",
    href: "/local",
  },
]

interface MainNavProps extends React.HTMLAttributes<HTMLElement> {}

export function MainNav({ className, ...props }: MainNavProps) {
  return (
    <nav className={cn("flex items-center space-x-4 lg:space-x-6", className)} {...props}>
      {items.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className="text-sm font-medium transition-colors hover:text-primary"
        >
          {item.title}
        </Link>
      ))}
    </nav>
  )
} 