"use client"

import Link from "next/link"
import Image from "next/image"
import { Category } from "@prisma/client"

interface CategoryCardProps {
  category: Category
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link
      href={`/categories/${category.id}`}
      className="group relative overflow-hidden rounded-lg border bg-background p-2"
    >
      <div className="aspect-square overflow-hidden rounded-md">
        {category.image ? (
          <Image
            src={category.image}
            alt={category.name}
            width={200}
            height={200}
            className="h-full w-full object-cover transition-transform group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center bg-muted">
            <span className="text-2xl font-semibold text-muted-foreground">
              {category.name[0]}
            </span>
          </div>
        )}
      </div>
      <div className="p-2">
        <h3 className="font-semibold">{category.name}</h3>
        {category.description && (
          <p className="text-sm text-muted-foreground">{category.description}</p>
        )}
      </div>
    </Link>
  )
} 