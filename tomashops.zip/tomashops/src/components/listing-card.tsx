"use client"

import * as React from "react"
import Link from "next/link"
import Image from "next/image"
import { Listing } from "@prisma/client"
import { Player } from "@mux/mux-player-react"
import { Button } from "@/components/ui/button"
import { Heart } from "lucide-react"
import { formatPrice } from "@/lib/utils"

interface ListingCardProps {
  listing: Listing
}

export function ListingCard({ listing }: ListingCardProps) {
  const [isPlaying, setIsPlaying] = React.useState(false)

  return (
    <div className="group relative overflow-hidden rounded-lg border bg-background">
      <Link href={`/listings/${listing.id}`} className="relative block aspect-square">
        {listing.videoUrl ? (
          <div
            className="relative h-full w-full"
            onMouseEnter={() => setIsPlaying(true)}
            onMouseLeave={() => setIsPlaying(false)}
          >
            <Player
              playbackId={listing.videoUrl}
              autoPlay={isPlaying}
              muted
              loop
              className="absolute inset-0 h-full w-full object-cover"
            />
            {!isPlaying && listing.images?.[0] && (
              <Image
                src={listing.images[0]}
                alt={listing.title}
                fill
                className="object-cover"
              />
            )}
          </div>
        ) : (
          listing.images?.[0] && (
            <Image
              src={listing.images[0]}
              alt={listing.title}
              fill
              className="object-cover transition-transform group-hover:scale-105"
            />
          )
        )}
      </Link>
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <h3 className="font-semibold">{listing.title}</h3>
            <p className="text-sm text-muted-foreground">{formatPrice(listing.price)}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={(e) => {
              e.preventDefault()
              // Add to wishlist functionality
            }}
          >
            <Heart className="h-4 w-4" />
            <span className="sr-only">Add to wishlist</span>
          </Button>
        </div>
        <div className="mt-2 flex items-center text-sm text-muted-foreground">
          <span>{listing.location}</span>
          <span className="mx-2">•</span>
          <span>{listing.condition}</span>
        </div>
      </div>
    </div>
  )
} 