"use client"

import Link from "next/link"

export default function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="flex flex-col space-y-4">
            <h3 className="text-lg font-semibold">About</h3>
            <Link href="/about" className="text-muted-foreground hover:text-foreground">
              How It Works
            </Link>
            <Link href="/safety" className="text-muted-foreground hover:text-foreground">
              Safety Guide
            </Link>
            <Link href="/shipping" className="text-muted-foreground hover:text-foreground">
              Shipping Guide
            </Link>
          </div>
          <div className="flex flex-col space-y-4">
            <h3 className="text-lg font-semibold">Legal</h3>
            <Link href="/privacy" className="text-muted-foreground hover:text-foreground">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-muted-foreground hover:text-foreground">
              Terms of Service
            </Link>
          </div>
          <div className="flex flex-col space-y-4">
            <h3 className="text-lg font-semibold">Support</h3>
            <Link href="/contact" className="text-muted-foreground hover:text-foreground">
              Contact Us
            </Link>
            <Link href="/faq" className="text-muted-foreground hover:text-foreground">
              FAQ
            </Link>
          </div>
          <div className="flex flex-col space-y-4">
            <h3 className="text-lg font-semibold">Social</h3>
            <Link href="https://twitter.com/tomashops" className="text-muted-foreground hover:text-foreground">
              Twitter
            </Link>
            <Link href="https://facebook.com/tomashops" className="text-muted-foreground hover:text-foreground">
              Facebook
            </Link>
            <Link href="https://instagram.com/tomashops" className="text-muted-foreground hover:text-foreground">
              Instagram
            </Link>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TomaShops™. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
} 